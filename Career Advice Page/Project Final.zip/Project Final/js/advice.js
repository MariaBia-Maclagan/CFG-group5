var email = window.prompt("Please enter your email here if you would like to join our community and receive our monthly newsletter:");
alert("Great!");
